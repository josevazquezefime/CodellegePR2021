function Saludar(saludo) {
    console.log("Hola, " + saludo);
}

Saludar("Kevin, buenos días");